"""
# Welcome to your CDK TypeScript project!

This is a blank project for TypeScript development with CDK.

The `cdk.json` file tells the CDK Toolkit how to execute your app.

## Useful commands

* `npm run build`   compile typescript to js
* `npm run watch`   watch for changes and compile
* `npm run test`    perform the jest unit tests
* `cdk deploy`      deploy this stack to your default AWS account/region
* `cdk diff`        compare deployed stack with current state
* `cdk synth`       emits the synthesized CloudFormation template
"""
import abc
import builtins
import datetime
import enum
import typing

import jsii
import jsii.compat
import publication

import aws_cdk.aws_iam
import aws_cdk.aws_lambda
import aws_cdk.aws_stepfunctions
import aws_cdk.aws_stepfunctions_tasks
import aws_cdk.core
import constructs

from ._jsii import *


class LambdaPowerTuner(aws_cdk.core.Construct, metaclass=jsii.JSIIMeta, jsii_type="cdk-lambda-powertuner.LambdaPowerTuner"):
    def __init__(self, scope: aws_cdk.core.Construct, id: str, *, lambda_resource: str, power_values: typing.Optional[typing.List[jsii.Number]]=None, visualization_url: typing.Optional[str]=None) -> None:
        """
        :param scope: -
        :param id: -
        :param lambda_resource: -
        :param power_values: -
        :param visualization_url: -
        """
        config = LambdaPowerTunerConfig(lambda_resource=lambda_resource, power_values=power_values, visualization_url=visualization_url)

        jsii.create(LambdaPowerTuner, self, [scope, id, config])


@jsii.data_type(jsii_type="cdk-lambda-powertuner.LambdaPowerTunerConfig", jsii_struct_bases=[], name_mapping={'lambda_resource': 'lambdaResource', 'power_values': 'powerValues', 'visualization_url': 'visualizationURL'})
class LambdaPowerTunerConfig():
    def __init__(self, *, lambda_resource: str, power_values: typing.Optional[typing.List[jsii.Number]]=None, visualization_url: typing.Optional[str]=None) -> None:
        """
        :param lambda_resource: -
        :param power_values: -
        :param visualization_url: -
        """
        self._values = {
            'lambda_resource': lambda_resource,
        }
        if power_values is not None: self._values["power_values"] = power_values
        if visualization_url is not None: self._values["visualization_url"] = visualization_url

    @builtins.property
    def lambda_resource(self) -> str:
        return self._values.get('lambda_resource')

    @builtins.property
    def power_values(self) -> typing.Optional[typing.List[jsii.Number]]:
        return self._values.get('power_values')

    @builtins.property
    def visualization_url(self) -> typing.Optional[str]:
        return self._values.get('visualization_url')

    def __eq__(self, rhs) -> bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs) -> bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return 'LambdaPowerTunerConfig(%s)' % ', '.join(k + '=' + repr(v) for k, v in self._values.items())


__all__ = [
    "LambdaPowerTuner",
    "LambdaPowerTunerConfig",
]

publication.publish()
